# Project 1 - Milestone 2 - Fameda Hossain


## Project Description

- Create a web app that shows top song(s) from your favorite artists and links to the lyrics. This app features user login, user registration, logout and user input that gets saved to a database.

### Information that appears on the web app:

- User Login
- User Registration
- User Logout
- Form to add Artist ID
- Artist Name
- Artist Image
- Song Name
- Album Art
- Song Preview
- Link to Genius Lyrics

## Technology Stack

- Python
    - Flask Framework
    - Flask-SQLAlchemy
    - Flask-Login
    - Jinja2
- HTML/CSS
    - HTML Forms
- PostgreSQL
- Heroku for deployment
- Black linter

## How this Application Works

This application begins with a sign in page that allows previous users to log in and view their saved artist's information. If a user is not registered, they will be prompted to visit the register page. If the user is new or does not have any saved artist ID's, the app will prompt them to save an artist ID. Otherwise, if they are a previous user their saved artist's information will appear on the page along with the option to save more artist ID's. A user can also log out.

This app takes in a user inputted artist ID and makes a request to the Spotify API (while also making sure that the artist ID is valid) to get the artist name, top songs, album art, and song preview. After this, a call to the Genius API is made in which I pass down the song name and artist name to get the link to the lyrics page. Then my app takes this information and passes it to the HTML to present it on the front end.

## Questions

1. What are at least 3 technical issues you encountered with your project? How did you fix them?
    - I had an issue where after a new user registered, they would add in an artist ID and it would save to the database but not update on the page. I needed to change when I was adding to my overall user artist ID list and make sure it occured after my POST request.
    - I solved an issue where my Artist model would not create and throw an error, I realized that I needed to create my loginUser model first since my Artist model had a foreign key from the loginUser model.
    - I also faced difficulty with determining when to render my template for the home page since there were various conditions I had to have and meet for different test cases. I was able to walk through my code and see how it needed to run and added the lines to make the code run correctly.

2. What are known problems (still existing), if any, with your project? If none exist, what additional features might you implement, and how?
- Currently, there are no problems with my project. The page loads dynamically. Some of the Spotify previews don't work, mostly due to copyright, so these previews can't be played. An additional feature I'd like to implement would be a new songs for artists section for each user, so based on the artists that they have saved, I'd find which songs are new for that artist and display those on the page. I'd use the Get All New Releases API from Spotify to do so.

3. What would you do to improve your project in the future? 
- I'd like to make the application have a better overall look and appearance with more User Interface.
- I'd also like to make it so that a user can search for an artist using their Name and not the artist ID through a search tool and get the relevant information for that artist.

4. How did your experience working on this milestone differ from what you pictured while working through the planning process? What was unexpectedly hard? Was anything unexpectedly easy?
- In the planning process I expected to do a lot of research since there were tools/tech I was unfamiliar with. This was true for my milestone work.
- Flask login was unexpectedly hard because the documentation was a bit sparse and skipped out on adding imports, resulting in some confusion with how to use it.
- I found the database easy to use.


## Imports

For API's:
- pip install requests
- pip install dotenv
- pip install os

For the web framework:
- pip install flask

For user session management:
- pip install flask-login
- pip install Flask-Session

For database PostgreSQL/SQLAlchemy:
- sudo apt install postgresql
- pip install flask-sqlalchemy
- pip install psycopg2-binary

For linting:
- pip install black


## How to Run the Application

1. Make sure all packages located in the imports section are correctly installed.
2. Clone this repository from github to your local drive using this command:
    - `git clone https://github.com/csc4350-f21/project1-fhossain6.git`
3. Create an .env file to store the environment variables:
    ```
    Spotify API Variables Needed:
    
    CLIENT_ID=''
    CLIENT_SECRET=''
    ```

    ```
    Genius API Variables Needed:

    GENIUS_TOKEN=''
    ```
    ```
    Create a Secret Key to use (cast to bytes):

    SECRET_KEY=b''

    ```
    ```
    Create a new remote database on your Heroku app: `heroku addons:create heroku-postgresql:hobby-dev -a {app-name-here}` no braces. And then get the database url by running `heroku config`. Make sure to replace `postgres` with `postgresql` in the url.

    DATABASE_URL=''
    ```

4. Run the app.py file using the command:
    - `python3 app.py`

## Check out my App deployed on Heroku here:
-  [Project 1 - Milestone 2 Live on Heroku](https://projectmilestone2-fhossain6.herokuapp.com/)