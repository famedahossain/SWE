from sqlalchemy.orm import backref
from genius import *
from spotify import *
import flask
from flask import session
import os
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin, LoginManager, login_user, login_required, logout_user
from sqlalchemy import ForeignKey
from flask_session import Session
from dotenv import find_dotenv, load_dotenv
from sqlalchemy.orm.relationships import foreign
from sqlalchemy.orm import relationship

app = flask.Flask(__name__)
load_dotenv(find_dotenv())

app.secret_key = os.getenv("SECRET_KEY")
app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv("DATABASE_URL")
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

db = SQLAlchemy(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"

# User and Artist Model
class loginUser(UserMixin, db.Model):
    uid = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(120), unique=True, nullable=False)

    def get_id(self):
        return self.uid


class Artists(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user = db.Column(db.String(120), ForeignKey("login_user.username"))
    artistID = db.Column(db.String(80))
    loginUser = db.relationship("loginUser", backref="Artists")

    def __repr__(self):
        return "<User %r>" % self.username


db.create_all()


@login_manager.user_loader
def load_user(user_id):
    return loginUser.query.get(user_id)


@app.route("/", methods=["GET", "POST"])
def login():
    user = flask.request.form.get("username")
    session["currentUser"] = user
    current = loginUser.query.filter_by(username=user).first()

    if flask.request.method == "POST":
        if current:
            login_user(current)
            return flask.redirect(flask.url_for("index"))

        else:
            flask.flash("This username is not recognized.")

    return flask.render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    users = loginUser.query.all()
    userList = []
    for user in users:
        userList.append(user.username)

    if flask.request.method == "POST":
        username = flask.request.form.get("username")

        if username in userList:
            flask.flash("This username already exists, please input another username.")

        else:
            newUser = loginUser(username=username)
            db.session.add(newUser)
            db.session.commit()
            return flask.redirect(flask.url_for("login"))

    return flask.render_template("register.html")


@app.route("/home", methods=["GET", "POST"])
@login_required
def index():
    current = session.get("currentUser", None)

    if flask.request.method == "POST":
        artist_id = flask.request.form.get("artistID")
        values = genius([artist_id])

        if values["valid"] == "invalid":
            flask.flash("This artist ID is not valid.")
            flask.flash("Please enter in a valid artist ID.")
        else:
            preexistingArtist = Artists.query.filter_by(
                user=current, artistID=artist_id
            )

            newArtist = Artists(user=current, artistID=artist_id)
            if newArtist not in preexistingArtist:
                db.session.add(newArtist)
                db.session.commit()

    artists = []

    for artist in Artists.query.filter_by(user=current):
        artists.append(artist.artistID)

    if len(artists) == 0:
        flask.flash("You do not have any artists saved.")
        artistarray = 0

    else:
        artistarray = len(artists)
        values = genius(artists)
        song = values["song"]
        artist = values["artist"]
        picture = values["picture"]
        genius_link = values["genius_link"]
        artist_image_url = values["artist_image_url"]
        preview_song_item = values["preview_song_item"]
        return flask.render_template(
            "index.html",
            artistarray=artistarray,
            artist=artist,
            song=song,
            picture=picture,
            genius_link=genius_link,
            artist_image_url=artist_image_url,
            preview_song_item=preview_song_item,
        )

    return flask.render_template("index.html", artistarray=artistarray)


@app.route("/logout")
@login_required
def logout():
    current = session.get("currentUser", None)
    logout_user()
    return flask.redirect(flask.url_for("login"))


if __name__ == "__main__":
    app.run(
        host=os.getenv("IP", "0.0.0.0"), port=int(os.getenv("PORT", 8080)), debug=True
    )
