import flask
import os
import json
from genius import *
from spotify import *
from flask import session
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin, LoginManager, login_user, login_required, logout_user
from sqlalchemy import ForeignKey
from flask_session import Session
from dotenv import find_dotenv, load_dotenv

load_dotenv(find_dotenv())

app = flask.Flask(__name__, static_folder="./build/static")
# This tells our Flask app to look at the results of `npm build` instead of the
# actual files in /templates when we're looking for the index page file. This allows
# us to load React code into a webpage. Look up create-react-app for more reading on
# why this is necessary.
bp = flask.Blueprint("bp", __name__, template_folder="./build")

app.secret_key = os.getenv("SECRET_KEY")
app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv("DATABASE_URL").replace(
    "postgres", "postgresql", 1
)
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

db = SQLAlchemy(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = "login"


class loginUser(UserMixin, db.Model):
    uid = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    artists = db.Column(db.String(100))

    def get_id(self):
        return self.uid


db.create_all()


@login_manager.user_loader
def load_user(user_id):
    return loginUser.query.get(user_id)


@bp.route("/index", methods=("GET", "POST"))
@login_required
def index():
    # TODO: insert the data fetched by your app main page here as a JSON
    current = session.get("currentUser", None)
    artist_users = loginUser.query.filter_by(username=current).first()
    fullListOfArtists = artist_users.artists

    if fullListOfArtists == None:
        flask.flash("You do not have any artists saved.")
        artistarray = 0
        DATA = {
            "artistarray": artistarray,
            "userArtistList": "",
            "artist": "",
            "song": "",
            "picture": "",
            "genius_link": "",
            "artist_image_url": "",
            "preview_song_item": "",
            "favs": [],
        }

    else:
        artist_whole = fullListOfArtists.split(",")
        values = genius(artist_whole)
        song = values["song"]
        artist = values["artist"]
        picture = values["picture"]
        genius_link = values["genius_link"]
        artist_image_url = values["artist_image_url"]
        preview_song_item = values["preview_song_item"]

        DATA = {
            "artistarray": len(artist_whole),
            "userArtistList": artist_whole,
            "artist": artist,
            "song": song,
            "picture": picture,
            "genius_link": genius_link,
            "artist_image_url": artist_image_url,
            "preview_song_item": preview_song_item,
            "favs": artist_whole,
        }

    data = json.dumps(DATA)
    return flask.render_template(
        "index.html",
        data=data,
    )


app.register_blueprint(bp)


@app.route("/", methods=["GET", "POST"])
def login():
    user = flask.request.form.get("username")
    session["currentUser"] = user
    current = loginUser.query.filter_by(username=user).first()

    if flask.request.method == "POST":
        if current:
            login_user(current)
            return flask.redirect(flask.url_for("bp.index"))

        else:
            flask.flash("This username is not recognized.")

    return flask.render_template("login.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    users = loginUser.query.all()
    userList = []
    for user in users:
        userList.append(user.username)

    if flask.request.method == "POST":
        username = flask.request.form.get("username")

        if username in userList:
            flask.flash("This username already exists, please input another username.")

        else:
            newUser = loginUser(username=username)
            db.session.add(newUser)
            db.session.commit()
            return flask.redirect(flask.url_for("login"))

    return flask.render_template("register.html")


@app.route("/returnArtists", methods=["POST"])
def add():
    current = session.get("currentUser", None)
    list_whole = flask.request.json.get("list_add")
    backupList = []
    error_array = []
    checker = False
    for item in list_whole:
        if item == "":
            list_whole.remove(item)
    for artistID in list_whole:
        values = genius([artistID])
        if values["valid"] == "invalid":
            checker = True
            error_array.append(artistID)
        else:
            backupList.append(artistID)
    joined_string = ",".join(backupList)
    error = ", ".join(error_array) + " is not a valid artist ID"
    loginUser.query.filter_by(username=current).update({"artists": joined_string})
    db.session.commit()

    return flask.jsonify({"list_server": list_whole, "Error": error, "Check": checker})


@app.route("/logout")
@login_required
def logout():
    current = session.get("currentUser", None)
    logout_user()
    return flask.redirect(flask.url_for("login"))


app.run(
    host=os.getenv("IP", "0.0.0.0"),
    port=int(os.getenv("PORT", 8081)),
)
