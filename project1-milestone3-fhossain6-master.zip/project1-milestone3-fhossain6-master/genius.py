# Project 1 - Fameda Hossain

import requests
import os
from dotenv import find_dotenv, load_dotenv
from spotify import spotify


def genius(artistList):
    values = spotify(artistList)
    valid = values["valid"]
    song = values["song"]
    artist = values["artist"]
    picture = values["picture"]
    artist_image_url = values["artist_image_url"]
    preview_song_item = values["preview_song_item"]

    load_dotenv(find_dotenv())
    GENIUS_TOKEN = os.getenv("GENIUS_TOKEN")

    if valid == "invalid":
        return {
            "valid": valid,
            "song": song,
            "picture": picture,
            "artist": artist,
            "genius_link": "",
            "artist_image_url": artist_image_url,
            "preview_song_item": preview_song_item,
        }

    # Authorization
    BASE_URL = "https://api.genius.com"
    searchURL = BASE_URL + "/search"

    headers = {"Authorization": "Bearer " + GENIUS_TOKEN}

    params = {"q": f"{song} {artist}"}

    # Get the response
    response = requests.get(searchURL, headers=headers, params=params)

    response_json = response.json()

    lyrics = []
    for item in response_json["response"]["hits"]:
        lyrics.append(item["result"]["url"])

    genius_link = lyrics[0]
    return {
        "valid": valid,
        "song": song,
        "picture": picture,
        "artist": artist,
        "genius_link": genius_link,
        "artist_image_url": artist_image_url,
        "preview_song_item": preview_song_item,
    }
