# Project 1 - Fameda Hossain

import requests
import base64
import os
from dotenv import find_dotenv, load_dotenv
import random
import json


def spotify(artistList):
    random_artist_choice = random.choice(artistList)

    load_dotenv(find_dotenv())
    CLIENT_ID = os.getenv("CLIENT_ID")
    CLIENT_SECRET = os.getenv("CLIENT_SECRET")

    # Authorization
    AUTH_URL = "https://accounts.spotify.com/api/token"
    headers = {}
    data = {}

    # Encode as Base64
    message = f"{CLIENT_ID}:{CLIENT_SECRET}"
    messageBytes = message.encode("ascii")
    base64Bytes = base64.b64encode(messageBytes)
    base64Message = base64Bytes.decode("ascii")

    headers["Authorization"] = f"Basic {base64Message}"
    data["grant_type"] = "client_credentials"

    # Post the response
    auth_response = requests.post(AUTH_URL, headers=headers, data=data)

    # Save the access token
    token = auth_response.json()["access_token"]

    # Calling the endpoint
    BASE_URL = f"https://api.spotify.com/v1/artists/{random_artist_choice}/top-tracks"
    ARTIST_IMAGE = f"https://api.spotify.com/v1/artists/{random_artist_choice}"

    headers = {"Authorization": "Bearer " + token}

    params = {"market": "US"}

    # Get artist image
    artist_image = requests.get(url=ARTIST_IMAGE, headers=headers)
    artist_image_json = artist_image.json()

    # Get the artist top tracks response
    response = requests.get(url=BASE_URL, headers=headers, params=params)

    response_json = response.json()

    try:
        if response_json["error"] and artist_image_json["error"]:
            valid = "invalid"
            return {
                "valid": valid,
                "song": "",
                "picture": "",
                "artist": "",
                "artist_image_url": "",
                "preview_song_item": "",
            }
        else:
            valid = "valid"
    except KeyError:
        pass

    artist_image_url = artist_image_json["images"][0]["url"]
    songs_pictures = {}
    preview_song = []
    # artists = []

    # Getting song and artist name, image url
    for value in response_json["tracks"]:
        try:
            if value["name"] not in songs_pictures:
                songs_pictures[value["name"]] = value["album"]["images"][0]["url"]
            preview_song.append(value["preview_url"])
            # artists.append(value["artists"][0]["name"])
        except KeyError:
            print("Couldn't fetch song")
            break

    song, picture = random.choice(list(songs_pictures.items()))
    keys = list(songs_pictures.keys())
    preview_song_item = preview_song[keys.index(song)]
    # artist = artists[0]
    artist = artist_image_json["name"]

    return {
        "valid": "valid",
        "song": song,
        "picture": picture,
        "artist": artist,
        "artist_image_url": artist_image_url,
        "preview_song_item": preview_song_item,
    }
