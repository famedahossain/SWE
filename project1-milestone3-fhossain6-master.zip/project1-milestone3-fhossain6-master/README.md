# Project 1 - Milestone 2 - Fameda Hossain


## Project Description

- Create a web app that shows top song(s) from your favorite artists and links to the lyrics. This app features user login, user registration, logout and user input that gets saved to a database. The user can see the artist ID's they currently have saved in their database and add and delete from it.

### Information that appears on the web app:

- User Login
- User Registration
- User Logout
- Form to add Artist ID
- Artist Name
- Artist Image
- Song Name
- Album Art
- Song Preview
- Link to Genius Lyrics
- User can add/delete Artist ID's from database

## Technology Stack

- Python
    - Flask Framework
    - Flask-SQLAlchemy
    - Flask-Login
    - Jinja2
- React
- HTML/CSS
    - HTML Forms
- PostgreSQL
- Heroku for deployment
- Black linter
- ESLint


## How this Application Works

This application begins with a sign in page that allows previous users to log in and view their saved artist's information. If a user is not registered, they will be prompted to visit the register page. If the user is new or does not have any saved artist ID's, the app will prompt them to save an artist ID. Otherwise, if they are a previous user their saved artist's information will appear on the page along with the option to save more artist ID's. A user can also log out.

This app takes in a user inputted artist ID and makes a request to the Spotify API (while also making sure that the artist ID is valid) to get the artist name, top songs, album art, and song preview. After this, a call to the Genius API is made in which I pass down the song name and artist name to get the link to the lyrics page. Then my app takes this information and passes it to the HTML to present it on the front end.

A user will also be able to see the artist ID's they have saved and be able to delete them or add new artist ID's. Upon doing the add and delete, the user's database will update to reflect the change.

## Questions

1. What are at least 3 technical issues you encountered with your project? How did you fix them?
    - I had an issue where the pages wouldn't sync up after I hit add, in that I would click add and the artist ID's would get added to the database, but you would only see that change reflected when you refrshed the page twice. I went in and checked how I was altering my states as well as adding in a reload to help the page refresh and show that new database information.
    - I solved an issue where my delete button would need to be clicked twice. I realized that I was calling set state for my delete function in too many places and React was getting confused. So I had to change my approach and fix how I was calling set state.
    - I also faced difficulty with my page not checking if the user didn't have any artists saved, it would show broken image links because those url's would not exist if the user didn't have any artist ID's saved. I was able to fix that by adding more strict requirements to my if condition check on the front end.

2. What part of the stack do you feel most comfortable with? What part are you least comfortable with?
- I was most comfortable working with the backend, specifically using Python and Flask. Python is primary coding language of mine so using it to debug was very helpful. Being able to do a print statement and check where issues were happening helped a great deal. I was least comfortable using React, mainly because the syntax was new and unfamiliar and I was also having issues with making sure updates were actually happening since I needed to check states.

3. What are known problems (still existing), if any, with your project? If none exist, what additional features might you implement, and how?
- Currently, there are no problems with my project. The page loads dynamically. Some of the Spotify previews don't work, mostly due to copyright, so these previews can't be played. An additional feature I'd like to implement would be a new songs for artists section for each user, so based on the artists that they have saved, I'd find which songs are new for that artist and display those on the page. I'd use the Get All New Releases API from Spotify to do so.

4. What would you do to improve your project in the future? 
- I'd like to make the application have a better overall look and appearance with more User Interface.
- I'd also like to make it so that a user can have a profile page and can visit other user profiles.

5. How did your experience working on this milestone differ from what you pictured while working through the planning process? What was unexpectedly hard? Was anything unexpectedly easy?
- React was a difficult JavaScript framework to use because I had minimal experience with it and wasn't fully sure of the syntax.

## Imports

For API's:
- pip install requests
- pip install dotenv
- pip install os

For the web framework:
- pip install flask

For user session management:
- pip install flask-login
- pip install Flask-Session

For database PostgreSQL/SQLAlchemy:
- sudo apt install postgresql
- pip install flask-sqlalchemy
- pip install psycopg2-binary

For linting:
- pip install black
- npm install eslint —-save-dev
- npm install eslint-config-airbnb —-save-dev

For React:
- npm install

For Unit Testing:
- pip install coverage
- npm install --save-dev @testing-library/react
- npm install --save-dev @testing-library/jest-dom


## How to Run the Application

1. Make sure all packages located in the imports section are correctly installed.
2. Clone this repository from github to your local drive using this command:
    - `git clone https://github.com/csc4350-f21/project1-fhossain6.git`
3. Create an .env file to store the environment variables:
    ```
    Spotify API Variables Needed:
    
    CLIENT_ID=''
    CLIENT_SECRET=''
    ```

    ```
    Genius API Variables Needed:

    GENIUS_TOKEN=''
    ```
    ```
    Create a Secret Key to use (cast to bytes):

    SECRET_KEY=b''

    ```
    ```
    Create a new remote database on your Heroku app: `heroku addons:create heroku-postgresql:hobby-dev -a {app-name-here}` no braces. And then get the database url by running `heroku config`. Make sure to replace `postgres` with `postgresql` in the url.

    DATABASE_URL=''
    ```
4. Run the command `npm run build` to build the project.
5. Run the app.py file using the command:
    - `python3 app.py`


## Check out my App deployed on Heroku here:
-  [Project 1 - Milestone 3 Live on Heroku](https://rocky-peak-03243.herokuapp.com/)


## You can also check out my previous App milestones to see my progress!
-  [Milestone 1 Live on Heroku](https://project1-fhossain6.herokuapp.com/)
-  [Milestone 2 Live on Heroku](https://projectmilestone2-fhossain6.herokuapp.com/)


# Flask and `create-react-app`

## Requirements
1. `npm install`
2. `pip install -r requirements.txt`

## Run Application
1. Run command in terminal (in your project directory): `npm run build`. This will update anything related to your `App.js` file (so `public/index.html`, any CSS you're pulling in, etc).
2. Run command in terminal (in your project directory): `python3 app.py`
3. Preview web page in browser 'localhost:8080/' (or whichever port you're using)

## Deploy to Heroku
1. Create a Heroku app: `heroku create --buildpack heroku/python`
2. Add nodejs buildpack: `heroku buildpacks:add --index 1 heroku/nodejs`
3. Push to Heroku: `git push heroku main`
