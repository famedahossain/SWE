import logo from './logo.svg';
import './App.css';
import { useState, useRef } from 'react';


function App() {
  // fetches JSON data passed in by flask.render_template and loaded
  // in public/index.html in the script with id "data"
  const args = JSON.parse(document.getElementById("data").text);

  const [front_end_list, setfront_end_list] = useState(args.favs);
  const [artID, setartID] = useState('');
  const [check, setCheck] = useState(false);
  const [error_message, set_error_message] = useState('');


  function addArtistToList() {
    var newList = front_end_list.concat(artID);
    setfront_end_list(newList);
    console.log(JSON.stringify({ "afterAdd": front_end_list }));
    setartID('');
  }

  function deleteArtistFromList(value) {
    const newList2 = front_end_list.filter(front_end_list => front_end_list !== value);
    setfront_end_list(newList2);
    console.log(JSON.stringify({ "deleteList": newList2 }));
  }

  function pushFromFrontToBackend() {
    fetch("/returnArtists", {
      method: "POST",
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ "list_add": front_end_list }),
    }).then(response => response.json()).then(data => {
      setfront_end_list(data.list_server);
      set_error_message(data.Error);
      setCheck(data.Check)
      window.location.reload();
    });
    console.log(JSON.stringify({ "setcheck": check }));
  }

  function NoneEmpty(arr) {
    for (var i = 0; i < arr.length; i++) {
      if (arr[i] === "") return false;
    }
    return true;
  }

  // TODO: Implement your main page as a React component.
  return (
    <div class="container">
      <>
        {
          (front_end_list.length > 0 && NoneEmpty(front_end_list) && args.artist_image_url !== "") ? (
            <>
              <br />

              <h1 class="artistName">{args.artist}</h1>
              <img class="artistImage" src={args.artist_image_url} alt="Image name" />
              <p class="songName">{args.song}</p>
              <img class="resize" src={args.picture} alt="Image name" />

              <br /><br /><br />

              <audio controls>
                <source src={args.preview_song_item} />
              </audio>

              <p class="genius"><a href={args.genius_link} target="_blank">Lyrics Here!</a></p>

              <h1 class="savedArtists">Your saved artists</h1>
              {front_end_list.map((value, index) => (
                <p class="listArtists" key={index}> {value} <button class="delete" onClick={() => { deleteArtistFromList(value) }}>Delete</button></p>
              ))}

            </>
          ) :
            <h1></h1>
        }
        <br />
        {
          check ? (<h2>{error_message}</h2>) : (<div></div>)
        }

        <h2 class="enterInArtist">Enter in an Artist ID to Save!</h2>

        <input class="search" type="text" value={artID} onChange={e => setartID(e.target.value)} name="artistID" placeholder="Artist ID" />
        <button type="button" onClick={() => addArtistToList()}>Add</button>
        <br />
        <button class="smnt" onClick={() => pushFromFrontToBackend()}>Save</button>

        <a href="/logout" class="logout">Log out</a>
      </>
    </div>
  );
}

export default App;
