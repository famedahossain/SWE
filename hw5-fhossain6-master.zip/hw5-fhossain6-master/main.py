import flask

app = flask.Flask(__name__)

tvShows = ["Parks and Recreation", "Brooklyn Nine Nine", "Avatar: the Last Airbender", "Modern Family", "The Good Place"]
imgUrls = [
    "https://www.oregonlive.com/resizer/paQpZ0sNik61AUqeSxlPP_HliS8=/1280x0/smart/cloudfront-us-east-1.images.arcpublishing.com/advancelocal/QFY6S6OCHRHWZOXFIH4RN7IKBU.jpg",
    "https://images-na.ssl-images-amazon.com/images/I/91egYFf+q9L._RI_.jpg",
    "https://lh3.googleusercontent.com/proxy/d8Bx5mMoeikTyOwz0LNMnGT4bPkLzIMsl5PygSdMKEwx1XYf2LandVTAcstmZK4g3zdnceQJiAg6BBzoTa3EDNOlMl6Dvb1aM_V0UQfWWYTJCaKVbpEHjazacOoGxZnafMm8dd4VN1lMHom2z-pdUvzOQZ9uol2fZQQm",
    "https://vam-image.media.syn-cdn.com/2b/de/2bdea480f1a69cfc3b621da060c239ffda8b38e3",
    "https://m.media-amazon.com/images/M/MV5BYmMxNjM0NmItNGU1Mi00OGMwLTkzMzctZmE3YjU1ZDE4NmFjXkEyXkFqcGdeQXVyODUxOTU0OTg@._V1_FMjpg_UX1000_.jpg"
]

@app.route("/")
def index():
    return flask.render_template(
        'index.html',
        len = len(tvShows),
        tvShows = tvShows,
        imgLen = len(imgUrls),
        imgUrls = imgUrls
    )

app.run(debug=True)
