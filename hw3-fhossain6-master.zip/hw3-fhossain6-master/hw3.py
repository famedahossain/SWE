# Homework 3 - Fameda Hossain

# Imports
import time
import math
import pandas as pd
import csv
import tempfile

# Question 1
print("---Question 1---")
def question1():
    startTime = time.time()

    for number in range(1,101):
        if number % 3 == 0 and number % 5 == 0:
            print('FizzBuzz')
        elif number % 3 == 0:
            print('Fizz')
        elif number % 5 == 0:
            print('Buzz')
        else:
            print(number)
            
    runTime = time.time() - startTime
    print('This program took ' + str(runTime) + ' seconds to run')

question1()
print("\n")

# Question 2
# Volume of a Sphere
print("---Question 2---")
def volumeOfSphere(radius):
    volume = (4/3)*math.pi*math.pow(radius,3)
    print('The volume of the sphere is ' + str(volume))

volumeOfSphere(5)
print("\n")

# Question 3
print("---Question 3---")
def question3():
    dict_Data = {
        "Title": ["1984","Animal Farm","Brave New World","Fahrenheit 451"], 
        "Author": ["George Orwell","George Orwell","Aldous Huxley","Ray Bradbury"], 
        "ISBN": ["978-0451524935","978-0451526342","978-0060929879","978-0345342966"], 
        "Pages": ["268","144","288","208"]
    }

    pd.DataFrame.from_dict(dict_Data).to_csv("Library.csv", index=False)
    print('The name of the file is Library.csv')

question3()
print("\n")

# Question 4
print("---Question 4---")
def question4():
    overallDict = pd.read_csv('Library.csv', header=0).to_dict('list')
    print(overallDict)

question4()
print("\n")

# Question 5
print("---Question 5---")
def question5():
    dict_Data = {
        "Title": ["1984","Animal Farm","Brave New World","Fahrenheit 451"], 
        "Author": ["George Orwell","George Orwell","Aldous Huxley","Ray Bradbury"], 
        "ISBN": ["978-0451524935","978-0451526342","978-0060929879","978-0345342966"], 
        "Pages": ["268","144","288","208"]
    }

    newFile = tempfile.TemporaryFile()

    with newFile as output:
        # Write to dict temp file
        pd.DataFrame.from_dict(dict_Data).to_csv(output, index=False)
        output.seek(0)

        # Convert temp csv file to dict
        overallDict = pd.read_csv(output, header=0).to_dict('list')
        print(overallDict)

        newFile.close()

question5()