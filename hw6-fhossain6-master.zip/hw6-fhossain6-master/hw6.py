# Homework 6 - Fameda Hossain

import requests
import base64
import os
from dotenv import find_dotenv, load_dotenv
import json

load_dotenv(find_dotenv())
CLIENT_ID = os.getenv('CLIENT_ID')
CLIENT_SECRET = os.getenv('CLIENT_SECRET')

# Authorization
AUTH_URL = "https://accounts.spotify.com/api/token"
headers = {}
data = {}

# Encode as Base64
message = f"{CLIENT_ID}:{CLIENT_SECRET}"
messageBytes = message.encode('ascii')
base64Bytes = base64.b64encode(messageBytes)
base64Message = base64Bytes.decode('ascii')

headers['Authorization'] = f"Basic {base64Message}"
data['grant_type'] = "client_credentials"

# Post the response
auth_response = requests.post(AUTH_URL, headers=headers, data=data)

# Save the access token
token = auth_response.json()['access_token']

# Calling the endpoint
BASE_URL = "https://api.spotify.com/v1/browse/new-releases"

headers = {
    "Authorization": "Bearer " + token
}

params = {
    'limit': 10
}

# Get the response
response = requests.get(url=BASE_URL, headers=headers, params=params)

response_json = response.json()

# Printing 10 new song releases
for value in response_json['albums']['items']:
    try:
        print(value['name'])
    except KeyError:
        print("Couldn't fetch data")
        break

